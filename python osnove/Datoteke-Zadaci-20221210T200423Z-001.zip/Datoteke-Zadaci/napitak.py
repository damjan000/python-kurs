class Napitak():
    def __init__(self, kolicina, naziv):
        self.kolicina = kolicina
        self.naziv = naziv

    def __str__(self):
        return "Kolicina: " + str(self.kolicina) + ", naziv: " + self.naziv


class Alkohol(Napitak):
    def __init__(self, kolicina, naziv, kolicina_alk):
        Napitak.__init__(self, kolicina, naziv)
        self.kolicina_alk = kolicina_alk

    def __str__(self):
        return Napitak.__str__(self) + ", kolicina alkohola: " + str(self.kolicina_alk)


class Sok(Napitak):
    def __init__(self, kolicina, naziv, kolicina_secera):
        Napitak.__init__(self, kolicina, naziv)
        self.kolicina_secera = kolicina_secera

    def __str__(self):
        return Napitak.__str__(self) + ", kolicina secera: " + str(self.kolicina_secera)


m = int(input("Unesite broj alkohola:"))
n = int(input("Unesite broj sokova:"))

lista_a = []
lista_s = []

while m > 0:
    k = float(input("Unesite kolicinu u litrima:"))
    naziv = input("Unesite naziv:")
    k_a = float(input("Unesite kolicinu alkohola:"))
    a = Alkohol(k, naziv, k_a)
    lista_a.append(a)
    m -= 1

while n > 0:
    k = float(input("Unesite kolicinu u litrima:"))
    naziv = input("Unesite naziv:")
    k_s = float(input("Unesite kolicinu secera:"))
    s = Sok(k, naziv, k_s)
    lista_s.append(s)
    n -= 1

f = open("alkohol.txt", "w")

for a in lista_a:
    s = "Naziv alkohola: " + a.naziv + ", kolicina: " + str(a.kolicina) + ", kol. alk.: " + str(a.kolicina_alk) + "\n"
    f.write(s)

f.close()

f = open("sokovi.txt", "w")

for s in lista_s:
    s = "Naziv soka: " + s.naziv + ", kolicina: " + str(s.kolicina) + ", kol. secera.: " + str(s.kolicina_secera) + "\n"
    f.write(s)