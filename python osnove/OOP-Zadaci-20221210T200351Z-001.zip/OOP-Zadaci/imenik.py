class Imenik():
    def __init__(self):
        self.lista_mobilnih = []
        self.lista_fiksnih = []

    def Ispis(self):
        while True:
            unos = int(input("Unesite 0 ako zelite sve mobilne telefone ili 1 ako zelite sve fiksne, za kraj izvrsavanja unesite 2:"))
            if unos == 0:
                for m in self.lista_mobilnih:
                    print(m)
            elif unos == 1:
                for f in self.lista_fiksnih:
                    print(f)
            elif unos == 2:
                break
            else:
                print("Pogresno ste unijeli!")


class Telefon():
    def __init__(self, vlasnik_broja, broj):
        self.vlasnik_broja = vlasnik_broja
        self.broj = broj

    def __str__(self):
        return "Vlasnik broj: " + self.vlasnik_broja + ", broj: " + self.broj


class MobilniTelefon(Telefon):

    def __init__(self, vlasnik_broja, broj, postpaid):
        Telefon.__init__(self, vlasnik_broja, broj)
        self.postpaid = postpaid

    def __str__(self):
        if self.postpaid:
            pom_str = ' ovo je postpaid broj.'
        else:
            pom_str = ' ovo je prepaid broj.'
        return Telefon.__str__(self) + pom_str


class FiksniTelefon(Telefon):

    def __init__(self, vlasnik_broja, broj, adresa):
        Telefon.__init__(self, vlasnik_broja, broj)
        self.adresa = adresa

    def __str__(self):
        return Telefon.__str__(self) + ", adresa: " + self.adresa


i = Imenik()

m = MobilniTelefon("Ognjen Djukic", "065224377", True)
f = FiksniTelefon("Milica Desancic", "051830304", "Vidovdanska BB")

i.lista_fiksnih.append(f)
i.lista_mobilnih.append(m)

i.Ispis()

