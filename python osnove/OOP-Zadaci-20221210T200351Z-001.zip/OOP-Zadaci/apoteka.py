class Apoteka():
    def __init__(self, grad, adresa):
        self.grad = grad
        self.adresa = adresa
        self.lista_lijekova = []
        self.lista_radnika = []

    def Info(self):
        print("Ukupno lijekova u apoteci:", len(self.lista_lijekova))
        print("Radnici u apoteci:")
        for r in self.lista_radnika:
            print(r)


class Lijek():
    def __init__(self, naziv, proizvodjac, cijena, upustvo, apoteka):
        self.naziv = naziv
        self.proizvodjac = proizvodjac
        self.cijena = cijena
        self.upustvo = upustvo
        apoteka.lista_lijekova.append(self)

    def __str__(self):
        return "Naziv lijeka: " + self.naziv + ", proizvodjac: " + self.proizvodjac + ", cijena: " + str(self.cijena) + "KM, upustvo: " + self.upustvo


class Radnik():
    def __init__(self, ime, prezime, plata, jmbg, telefon, apoteka):
        self.ime = ime
        self.prezime = prezime
        self.plata = plata
        self.jmbg = jmbg
        self.telefon = telefon
        apoteka.lista_radnika.append(self)

    def __str__(self):
        return "Ime: " + self.ime + ", prezime: " + self.prezime + ", plata: " + str(self.plata) + "KM, jmbg: " + self.jmbg + ", telefon: " + self.telefon


apoteka = Apoteka("Banja Luka", "Kralja Petra II")
lijek1 = Lijek("Brufen", "Eurofarm", 7.5, "Dnevno 3 puta piti.", apoteka)
radnik1 = Radnik("Marko", "Markovic", 1200, "1111999100100", "065/222-222", apoteka)


apoteka.Info()