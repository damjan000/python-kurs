class VideoIgra():

    def __init__(self, naziv):
        self.naziv = naziv

    def __str__(self):
        return "Naziv igre: " + self.naziv


class TicTacToe(VideoIgra):
    def __init__(self, naziv):
        VideoIgra.__init__(self, naziv)
        self.board = [['-', '-', '-'], ['-', '-', '-'], ['-', '-', '-']]

    def Info(self):
        for i in self.board:
            print(i)


class Sudoku(VideoIgra):
    def __init__(self, naziv, level):
        VideoIgra.__init__(self, naziv)
        self.board = [['-', '-', '-', '-', '-', '-', '-', '-', '-'],
                      ['-', '-', '-', '-', '-', '-', '-', '-', '-'],
                      ['-', '-', '-', '-', '-', '-', '-', '-', '-'],
                      ['-', '-', '-', '-', '-', '-', '-', '-', '-'],
                      ['-', '-', '-', '-', '-', '-', '-', '-', '-'],
                      ['-', '-', '-', '-', '-', '-', '-', '-', '-'],
                      ['-', '-', '-', '-', '-', '-', '-', '-', '-'],
                      ['-', '-', '-', '-', '-', '-', '-', '-', '-'],
                      ['-', '-', '-', '-', '-', '-', '-', '-', '-']]
        self.level = level

    def Info(self):
        print("Level: ", self.level)
        for i in self.board:
            print(i)


class IceTower(VideoIgra):
    def __init__(self, naziv, name, score):
        VideoIgra.__init__(self, naziv)
        self.playerName = name
        self.score = score

    def Info(self):
        print("Player Name:", self.playerName)
        print("Score:", str(self.score))


iksoks = TicTacToe("Tic3")
sudoku = Sudoku("Sudoku1,", "Hard")
iceTower = IceTower("Ice", "Ognjen", 3850)

# iksoks.board[0][0] = 'x'

iksoks.Info()
sudoku.Info()
iceTower.Info()