class Osoba():
    def __init__(self, ime, prezime, jmbg, visina, tezina, br_godina):
        self.ime = ime
        self.prezime = prezime
        self.jmbg = jmbg
        self.visina = visina
        self.tezina = tezina
        self.br_godina = br_godina

    def Godine(self):
        if self.br_godina < 18:
            print("Maloljetna osoba!")
        elif self.br_godina > 65:
            print("Penzioner")
        else:
            print("Punoljetna osoba, ali nije penzioner!")

    def Info(self):
        print("Ime i prezime:", self.ime, self.prezime)
        print("JMBG:", self.jmbg)
        print("Visina:", self.visina)
        print("Tezina:", self.tezina)
        print("Godine:", self.br_godina)


o1 = Osoba("Pero", "Peric", 1111995101010, 180, 80, 26)
o1.Godine()
o1.Info()