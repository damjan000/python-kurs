class Uredjaj():
    def __init__(self, jacina, kwh, proizvodjac, sirina, dubina, visina, cijena):
        self.jacina = jacina
        self.kwh = kwh
        self.proizvodjac = proizvodjac
        self.sirina = sirina
        self.dubina = dubina
        self.visina = visina
        self.cijena = cijena

    def __str__(self):
        return "Jacina: " + str(self.jacina) + ", kW/h" + str(self.kwh) + ", proizvodjac: " + self.proizvodjac + ", sirina: " + str(self.sirina) + ", visina: " + str(self.visina) + ", dubina: " + str(self.dubina) + ", cijena: " + str(self.cijena)


class TV(Uredjaj):
    def __init__(self, jacina, kwh, proizvodjac, sirina, dubina, visina, cijena, dijagonala):
        Uredjaj.__init__(self, jacina, kwh, proizvodjac, sirina, dubina, visina, cijena)
        self.dijagonala = dijagonala

    def __str__(self):
        return Uredjaj.__str__(self) + ", dijagonala: " + str(self.dijagonala)


class Frizider(Uredjaj):
    def __init__(self, jacina, kwh, proizvodjac, sirina, dubina, visina, cijena, min_temp, max_temp):
        Uredjaj.__init__(self, jacina, kwh, proizvodjac, sirina, dubina, visina, cijena)
        self.min_temp = min_temp
        self.max_temp = max_temp

    def __str__(self):
        return Uredjaj.__str__(self) + ", min. temp: " + str(self.min_temp) + ", max. temp: " + str(self.max_temp)


class VesMasina(Uredjaj):
    def __init__(self, jacina, kwh, proizvodjac, sirina, dubina, visina, cijena, kilaza):
        Uredjaj.__init__(self, jacina, kwh, proizvodjac, sirina, dubina, visina, cijena)
        self.kilaza = kilaza

    def __str__(self):
        return Uredjaj.__str__(self) + ", KG: " + str(self.kilaza)


ukupno_sa_43 = 0
ukupno_sa_55 = 0
ukupno_sa_65 = 0

listaTv = []

n = int(input("Unesite broj koliko zelite televizora:"))

while n > 0:
    jacina = int(input("Unesite jacinu:"))
    kwh = float(input("Unesite kWh:"))
    proizvodjac = input("Unesite proizvodjaca:")
    sirina = float(input("Unesite sirinu:"))
    dubina = float(input("Unesite dubinu:"))
    visina = float(input("Unesite visinu:"))
    cijena = float(input("Unesite cijenu:"))
    dijagonala = float(input("Unesite dijagonalu u cm:"))
    tv = TV(jacina, kwh, proizvodjac, sirina, dubina, visina, cijena, dijagonala)
    listaTv.append(tv)
    n -= 1

for tv in listaTv:
    if tv.dijagonala == 43:
        ukupno_sa_43 += 1
    elif tv.dijagonala == 55:
        ukupno_sa_55 += 1
    elif tv.dijagonala == 65:
        ukupno_sa_65 += 1

print("Sa 43 incha ih ima: ", ukupno_sa_43)
print("Sa 55 incha ih ima: ", ukupno_sa_55)
print("Sa 65 incha ih ima: ", ukupno_sa_65)
