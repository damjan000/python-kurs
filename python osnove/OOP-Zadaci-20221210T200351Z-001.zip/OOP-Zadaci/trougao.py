class Trougao():
    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c

    def Info(self):
        print("Stranica a:", self.a)
        print("Stranica b:", self.b)
        print("Stranica c:", self.c)


n = int(input("Unesite broj trouglova:"))

while n > 0:
    a = int(input("Unesite stranicu a:"))
    b = int(input("Unesite stranicu b:"))
    c = int(input("Unesite stranicu c:"))
    t = Trougao(a, b, c)
    t.Info()
    n -= 1