class Profesor():
    def __init__(self, ime, prezime, email, plata):
        self.ime = ime
        self.prezime = prezime
        self.email = email
        self.plata = plata

    def Info(self):
        print("Ime i prezime:", self.ime, self.prezime)
        print("Email:", self.email)
        print("Plata:", self.plata)


p1 = Profesor("Pero", "Peric", "pero@gmail.com", 10000)
p2 = Profesor("Simo", "Simic", "simo@gmail.com", 22000)
p3 = Profesor("Marko", "Markovic", "marko@gmail.com", 80000)

profesori = []
profesori.append(p1)
profesori.append(p2)
profesori.append(p3)

najmanja = p1.plata
najveca = p1.plata
sve_plate = 0

for p in profesori:
    if p.plata > najveca:
        najveca = p.plata
    elif p.plata < najmanja:
        najmanja = p.plata
    sve_plate += p.plata

print("Najveca plata:", najveca)
print("Najmanja plata:", najmanja)
print("Prosjecna plata:", sve_plate/profesori.__len__())