f = open("brojevi.txt", "r")
suma = 0

for b in f:
    suma += int(b)

s = open("suma.txt", "w")
s.write("Suma brojeva: " + str(suma))