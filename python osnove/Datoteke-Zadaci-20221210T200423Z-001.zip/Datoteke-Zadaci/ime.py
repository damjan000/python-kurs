f = open("ime.txt", "w")

while True:
    unos = input("Unesite tekst:")
    if unos == "Nikola":
        f.write(unos)
        break
    else:
        print("Niste unijeli svoje ime!")
