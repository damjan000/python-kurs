class RentACar():
    def __init__(self):
        self.lista_automobila = []
        self.lista_motora = []
        self.lista_autobusa = []

    def Info(self):
        print("Ukupan broj vozila u Rent A Car-u je:", len(self.lista_automobila) + len(self.lista_motora) + len(self.lista_autobusa))
        print("Svi automobili u Rent A Car-u:\n")
        for a in self.lista_automobila:
            print(a)
        print("Svi motori u Rent A Car-u:\n")
        for m in self.lista_motora:
            print(m)
        print("Svi autobusi u Rent A Car-u:\n")
        for ab in self.lista_autobusa:
            print(ab)


class Vozilo():
    def __init__(self, proizvodjac, model, godina, ks):
        self.proizvodjac = proizvodjac
        self.model = model
        self.godina = godina
        self.ks = ks

    def __str__(self):
        return "Proizvodjac: " + self.proizvodjac + ", model: " + self.model + ", godina: " + str(self.godina) + ", konjskih snaga: " + str(self.ks)


class Automobil(Vozilo):
    def __init__(self, proizvodjac, model, godina, ks, broj_sasije, r):
        Vozilo.__init__(self, proizvodjac, model, godina, ks)
        self.broj_sasije = broj_sasije
        r.lista_automobila.append(self)

    def __str__(self):
        return Vozilo.__str__(self) + ", broj sasije automobila: " + str(self.broj_sasije)


class Motor(Vozilo):
    def __init__(self, proizvodjac, model, godina, ks, max_brzina, r):
        Vozilo.__init__(self, proizvodjac, model, godina, ks)
        self.max_brzina = max_brzina
        r.lista_motora.append(self)

    def __str__(self):
        return Vozilo.__str__(self) + ", maksimalna brzina motora: " + str(self.max_brzina)


class Autobus(Vozilo):
    def __init__(self, proizvodjac, model, godina, ks, max_nosivost, r):
        Vozilo.__init__(self, proizvodjac, model, godina, ks)
        self.max_nosivost = max_nosivost
        r.lista_autobusa.append(self)

    def __str__(self):
        return Vozilo.__str__(self) + ", maksimalna nosivost u tonama: " + str(self.max_nosivost)


r = RentACar()
a1 = Automobil("Audi", "A3", 2018, 130, 15315486, r)
a2 = Automobil("Mercedes", "C220", 2016, 150, 15648123, r)

m1 = Motor("Honda", "CBR-1000", 2014, 130, 330, r)

ab1 = Autobus("MAN", "AA", 2020, 300, 7, r)

r.Info()