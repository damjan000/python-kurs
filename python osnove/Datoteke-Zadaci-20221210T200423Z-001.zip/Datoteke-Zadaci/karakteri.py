f = open("test.txt", "r")

str = f.readlines()
count = 0

for s in str:
    for c in s:
        if c != ' ' and c != '\n':
            count += 1

print("Ukupno karaktera:", count)
