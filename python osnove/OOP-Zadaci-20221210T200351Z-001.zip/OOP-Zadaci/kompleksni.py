class Kompleksni():

    def __init__(self, realni, imaginarni):
        self.re = realni
        self.im = imaginarni

    def Saberi(self, other):
        self.re = self.re + other.re
        self.im = self.im + other.im

    def Oduzimanje(self, other):
        self.re = self.re - other.im
        self.im = self.im - other.im

    def Ispis(self):
        print(self.re, '+', self.im, 'j')


z1 = Kompleksni(2, 2)
z1.Ispis()

z2 = Kompleksni(3, 3)

z1.Saberi(z2)
z1.Ispis()
