class Student():
    def __init__(self, ime, prezime, indeks, email, jmbg, adresa, telefon):
        self.ime = ime
        self.prezime = prezime
        self.indeks = indeks
        self.email = email
        self.jmbg = jmbg
        self.adresa = adresa
        self.telefon = telefon
        self.prosjek = 0

    def Info(self):
        print("Ime i prezime:", self.ime, self.prezime)
        print("Indeks:", self.indeks)
        print("Email:", self.email)
        print("JMBG:", self.jmbg)
        print("Adresa:", self.adresa)
        print("Telefon:", self.telefon)
        print("Prosjek ocjena:", self.prosjek)


student = Student("Ognjen", "Djukic", "1181/14", "ognjen@gmail.com", 1111995100000, "Adresa 1", "065/224-377")
count = 0
suma = 0
broj_ocjena = int(input("Unesite broj ocjena:"))

while broj_ocjena > 0:
    ocjena = int(input("Unesite ocjenu za studenta:"))
    if 6 <= ocjena <= 10:
        suma += ocjena
        count += 1
        broj_ocjena -= 1
    else:
        print("Niste unijeli dobru ocjenu (6-10)!")

student.prosjek = suma / count

student.Info()


