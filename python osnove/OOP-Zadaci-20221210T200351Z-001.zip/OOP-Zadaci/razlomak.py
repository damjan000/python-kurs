class Razlomak():

    def __init__(self, brojilac, imenilac):
        self.brojilac = brojilac
        self.imenilac = imenilac

    def Saberi(self, other):
        self.brojilac = (self.brojilac * other.imenilac) + (self.imenilac * other.brojilac)
        self.imenilac = self.imenilac * other.imenilac

    def Ispis(self):
        print(self.brojilac, "/", self.imenilac)


r1 = Razlomak(3, 4)
r2 = Razlomak(3, 4)

r1.Ispis()

r1.Saberi(r2)

r1.Ispis()