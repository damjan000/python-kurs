class Kafic():
    def __init__(self, ime, adresa, br_stolova, promet):
        self.ime = ime
        self.adresa = adresa
        self.br_stolova = br_stolova
        self.promet = promet

    def Info(self):
        print("Ime kafica:", self.ime)
        print("Adresa:", self.adresa)
        print("Broj stolova u kaficu:", self.br_stolova)
        print("Promet:", self.promet)

        if self.promet > 50000:
            print("Kafic:", self.ime, "je veliki SP!")
        else:
            print("Kafic", self.ime, "je mali SP!")


k1 = Kafic("Kab", "Kralja Petra II", 20, 76050)
k1.Info()

k2 = Kafic("Hey Joe", "Kralja Petra II", 15, 46500)
k2.Info()

