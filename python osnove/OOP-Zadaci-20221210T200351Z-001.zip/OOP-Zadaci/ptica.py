class Ptica():

    def __init__(self, boja, sirina_krila, naziv, staniste):
        self.boja = boja
        self.sirina_krila = sirina_krila
        self.naziv = naziv
        self.staniste = staniste

    def Boja(self):
        print("Boja:", self.boja)

    def SirinaKrila(self):
        print("Sirina krila:", self.sirina_krila)

    def Naziv(self):
        print("Naziv ptice:", self.naziv)

    def Staniste(self):
        print("Staniste:", self.staniste)


p1 = Ptica("Zelena", 200, "Mutant Golub", "Lijepo")
p1.Boja()
p1.Naziv()
p1.SirinaKrila()
p1.Staniste()