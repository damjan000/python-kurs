class Slatko():

    def __init__(self, naziv, tezina, kalorije):
        self.naziv = naziv
        self.tezina = tezina
        self.kalorije = kalorije

    def Info(self):
        print("Naziv:", self.naziv)
        print("Tezina:", self.tezina)
        print("Kalorija:", self.kalorije)


slatkisi = []

n = int(input("Unesite broj slatkisa:"))
while n > 0:
    naziv = input("Unesite naziv slatkisa:")
    tezina = float(input("Unesite tezinu slatkisa:"))
    kalorije = int(input("Unesite kalorije slatkisa:"))
    s = Slatko(naziv, tezina, kalorije)
    slatkisi.append(s)
    n -= 1

for s in slatkisi:
    if s.kalorije >= 2000:
        print(s.naziv, "je tesko sladak!")
    elif 500 <= s.kalorije <= 1999:
        print(s.naziv, "je srednje sladak!")
    else:
        print(s.naziv, "je slabo sladak!")
