class Hotel():
    def __init__(self, sobe, br_soba, br_spratova):
        self.sobe = sobe
        self.br_soba = br_soba
        self.br_spratova = br_spratova

    def Info(self):
        for s in self.sobe:
            s.Info()


class Soba():
    def __init__(self, broj, br_kreveta, br_sprata, cijena, slobodna):
        self.broj = broj
        self.br_kreveta = br_kreveta
        self.br_sprata = br_sprata
        self.cijena = cijena
        self.slobodna = slobodna

    def Info(self):
        print("Broj sobe:", self.broj)
        print("Broj kreveta:", self.br_kreveta)
        print("Sprat:", self.br_sprata)
        print("Cijena po noci:", self.cijena)
        if self.slobodna:
            print("Soba je slobodna!")
        else:
            print("Soba nije slobodna!")
        print("=======================")

    def Zaduzi(self):
        if self.slobodna is True:
            self.slobodna = False
        else:
            print("Trazena soba je vec zauzeta!")


sobe = []

i = 2
while i > 0:
    broj = int(input("Unesite broj sobe:"))
    br_kreveta = int(input("Unesite broj kreveta u sobi:"))
    br_sprata = int(input("Unesite sprat:"))
    cijena = float(input("Cijena sobe:"))
    slobodna = True
    i -= 1
    s = Soba(broj, br_kreveta, br_sprata, cijena, slobodna)
    sobe.append(s)

h = Hotel(sobe, sobe.__len__(), 2)
h.Info()

n = int(input("Unesite broj sobe da bi je zaduzili:"))
for s in sobe:
    if s.broj == n:
        if s.slobodna:
            s.slobodna = False
            print("Soba:", s.broj, "je upravo zaduzena!")
        else:
            print("Soba:", s.broj, "je vec zaduzena!")
    else:
        print("Soba sa unesenim brojem ne postoji!")


h.Info()
